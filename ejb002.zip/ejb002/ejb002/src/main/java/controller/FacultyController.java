
package controller;

import entities.Faculty;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import model.FacultyFacade;


@Named(value = "facultyController")
@SessionScoped
public class FacultyController implements Serializable {

    @EJB
    private FacultyFacade facultyFacade;
    private Faculty faculty=new faculty();

    public Faculty getFaculty() {
        return faculty;
    }

    public void setFaculty(Faculty faculty) {
        this.faculty = faculty;
    }
    
    public FacultyFacade getFacultyFacade() {
        return facultyFacade;
    }

    public void setFacultyFacade(FacultyFacade facultyFacade) {
        this.facultyFacade = facultyFacade;
    }

    /**
     * Creates a new instance of FacultyController
     */
    public FacultyController() {
    }
    public List<Faculty> findAll()
    {
        return this.facultyFacade.findAll();
    }
    public String insert()
    {
        this.facultyFacade.create(faculty);
        this.faculty=new Faculty();
        return "index";
    }
    public String Update(Faculty faculty)
    {
        this.faculty=faculty;
        return "update";
    }
    public String update(){
        this.facultyFacade.edit(faculty);
        this.faculty = faculty;
        return "index";
    }
    public void delete(Faculty faculty){
        this.facultyFacade.remove(faculty);        
    }


    
}
