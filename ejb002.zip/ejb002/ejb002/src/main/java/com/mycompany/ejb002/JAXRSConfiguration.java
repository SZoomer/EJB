package com.mycompany.ejb002;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


@ApplicationPath("resources")
public class JAXRSConfiguration extends Application {
    
}
